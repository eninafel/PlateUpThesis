<?php
declare(strict_types=1);

namespace PlateUp;

/** Reads KEY=value lines from backend/.env (and falls back to real environment variables). */
final class Env
{
    private static array $values = [];

    public static function load(string $file): void
    {
        if (!is_readable($file)) {
            return;
        }
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
                continue;
            }
            [$key, $value] = explode('=', $line, 2);
            self::$values[trim($key)] = trim($value, " \t\"'");
        }
    }

    public static function get(string $key, string $default = ''): string
    {
        if (isset(self::$values[$key]) && self::$values[$key] !== '') {
            return self::$values[$key];
        }
        $fromServer = getenv($key);
        return ($fromServer !== false && $fromServer !== '') ? $fromServer : $default;
    }
}
